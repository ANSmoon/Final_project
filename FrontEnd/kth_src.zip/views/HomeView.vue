<template>
  <main>
    <div>
      <h1>Welcome To The Show</h1>
      <RouterLink to="kakao">KAKAO</RouterLink> |
      <RouterLink to="/game/basic">BASIC</RouterLink> |
      <RouterLink to="/game/kbo">KBO</RouterLink> |
      <RouterLink to="/game/kleague">KLEAGUE</RouterLink> |
      <RouterLink to="/game/champs">CHAMPIONSLEAGUE</RouterLink> |
      <RouterLink to="/game/esports">E-SPORTS</RouterLink> |
      <RouterLink to="rank">RANK</RouterLink> |
      <RouterLink to="arena">ARENA</RouterLink> |
      
    </div>
  </main>
</template>

<script></script>
