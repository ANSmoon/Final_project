import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";

const REST_FIGHT_API = `http://localhost:8080/ansmoon/fight`;
export const useFightStore = defineStore("fight", () => {
  const fightList = ref([]);
  const getFightList = async (id) => {
    await axios.get(`${REST_FIGHT_API}/list?id=${id}`).then((response) => {
      fightList.value = response.data;
    });
  };
  return { fightList, getFightList };
});
