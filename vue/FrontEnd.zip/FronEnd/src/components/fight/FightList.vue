<template>
  <div id="app">
    <v-app id="inspire">
      <div>
        <v-layout column justify-center align-center>
          <v-subheader>Offset Top</v-subheader>
        </v-layout>
        <table>
          <v-container
            id="scroll-target"
            style="max-height: 200px"
            class="scroll-y"
            v-scroll="onScroll"
          >
            <tr>
              <th>번호</th>
              <th>댓글</th>
              <th>상대</th>
              <th>time</th>
              <th>수정</th>
              <th>삭제</th>
            </tr>
            <tr
              v-for="(fight, index) in fightStore.fightList"
              :key="fight.fightId"
            >
              <td>{{ index + 1 }}</td>
              <td>
                {{ fight.content }}
              </td>
              <td>{{ fight.fighter }}</td>
              <td>{{ fight.fightDay }}</td>
              <td>
                <button @click="updataFight" v-if="checkUser">수정</button>
              </td>
              <td>
                <button @click="deleteFight" v-if="checkUser">삭제</button>
              </td>
            </tr>
          </v-container>
        </table>
        <!-- <v-layout
          v-scroll:#scroll-target="onScroll"
          column
          align-center
          justify-center
          style="height: 1000px"
        >
        </v-layout> -->
      </div>
    </v-app>
  </div>
</template>

<script setup>
import { onMounted, ref } from "vue";
import { useFightStore } from "@/stores/fight";
import { useRoute, useRouter } from "vue-router";

const offsetTop = ref(0);
const onScroll = function (e) {
  offsetTop.value = e.target.scrollTop;
};

const fightStore = useFightStore();
const route = useRoute();
const router = useRouter();

const checkUser = ref(true);

onMounted(async () => {
  await fightStore.getFightList(route.params.arenaId);
});
</script>

<style scoped>
.scroll-y {
  overflow-y: auto;
}

table {
  border-collapse: collapse;
  margin-top: 20px;
}

th,
td {
  border: 1px solid #ddd;
  padding: 8px;
}

th {
  background-color: #f2f2f2;
  text-align: left;
}

tbody tr:nth-child(even) {
  background-color: #f9f9f9;
}

tbody tr:hover {
  background-color: #f1f1f1;
}
</style>
