import { ref } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
const apiKey = '552370aac9156fc809ee26c40f3a05dc';
const url = "https://api.kakaobrain.com/v1/inference/kogpt/generation";

export const useKakaoStore = defineStore("kakao", () => {

    const question = "정답이 '브라질'인 퀴즈에 대한 힌트를 한 줄로 한다면?"
    const hint = ref("");

    const getHint = function() {           
        axios.post(
            url, 
            {
                prompt: question,
                max_tokens: 50
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    Authorization: `KakaoAK ${apiKey}`,
                },
            }
        )
        .then((response) => {
            hint.value = response.data.output;
        })
        
    }
    
  return { hint, getHint };
});
