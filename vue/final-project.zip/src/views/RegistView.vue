<template>
  <div>
    <fieldset>
      <div>
        <label for="name">NAME</label>
        <input type="text" id="name" v-model="registData.userName" />
      </div>
      <div>
        <label for="id">ID</label>
        <input type="text" id="id" v-model="registData.userId" />
        <button @click="checkId">CHECK</button>
      </div>
      <div>
        <label for="password">PW</label>
        <input type="password" id="password" v-model="registData.password" />
      </div>
      <div>
        <label for="nickname">NICKNAME</label>
        <input type="text" id="nickname" v-model="registData.nickName" />
        <button @click="checkNick">CHECK</button>
      </div>
      <div>
        <button @click="registUser">REGIST</button>
      </div>
    </fieldset>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "@/stores/user";

const userStore = useUserStore();
const idconf = ref(false);
const nickconf = ref(true);
const registData = ref({
  userName: "",
  userId: "",
  password: "",
  nickName: "",
});

const registUser = async () => {
  console.log("regist");
  console.log(idconf.value);
  console.log(nickconf.value);
  if (idconf.value && nickconf.value) {
    if (registData.userName !== null && registData.userId !== null)
      await userStore.registUser(registData.value);
  } else if (!idconf.value) {
    alert("ID 중복을 확인하세요");
  } else if (!nickconf.value) {
    alert("NICKNAME 중복을 확인하세요");
  }
};

const checkId = async () => {
  console.log("idcheck");
  console.log(userStore.duplcheck);
  await userStore.checkParam("userId", registData.value.userId);
  idconf.value = userStore.duplcheck;
  console.log(userStore.duplcheck);
};

const checkNick = async () => {
  console.log("nickcheck");
  console.log(userStore.duplcheck);

  await userStore.checkParam("nickname", registData.value.nickName);

  nickconf.value = userStore.duplcheck;
  console.log(userStore.duplcheck);
};
</script>

<style scoped></style>
