import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
import { useRoute, useRouter } from "vue-router";

const REST_USER_API = `http://localhost:8080/ansmoon/user`;
export const useUserStore = defineStore("user", () => {
  const route = useRoute();
  const router = useRouter();

  const duplcheck = ref(false);

  const loginUser = function (loginData) {
    axios
      .post(`${REST_USER_API}/login`, loginData)
      .then((response) => {
        const nickName = response.data;
        sessionStorage.setItem("user", nickName);
        console.log(nickName);
      })
      .catch(() => {
        alert("로그인 정보를 확인하세요");
      });
  };

  const registUser = function (registData) {
    axios.post(`${REST_USER_API}/regist`, registData).then((response) => {
      alert("등록 성공");
      router.push({ name: "login" });
    });
  };

  const checkParam = (name, value) => {
    return new Promise((resolve) => {
      axios
        .get(`${REST_USER_API}/check?name=${name}&value=${value}`)
        .then((response) => {
          duplcheck.value = true;
          alert("사용 가능합니다");
          resolve(true);
        })
        .catch(() => {
          duplcheck.value = false;
          alert("중복입니다");
          resolve(false);
        });
    });
  };
  return { loginUser, registUser, checkParam, duplcheck };
});
