<template>
    <div>
        <h2>ansmoon's page</h2>
        <h4>...</h4>
        <div>
            <h1>GPT TEST</h1>
            <button @click="getHint">Hint</button>
            <div>
                {{ gameStore.hint }}
            </div>
        </div>
    </div>
</template>

<script setup>
import { useGameStore } from '@/stores/game';
import { ref } from 'vue';
const gameStore = useGameStore();

const getHint = function() {
    gameStore.getHint();
    console.log("hint out")
}

</script>

<style scoped>

</style>