<template>
  <main>
    <div>
      <h1>Welcome To The Show</h1>
      <RouterLink to="kakao">KAKAO</RouterLink> | 
      <RouterLink to="game">START</RouterLink> | 
      <RouterLink to="rank">RANK</RouterLink>
    </div>
  </main>
</template>

<script>


</script>
