import { ref, computed } from "vue";
import { defineStore } from "pinia";
import axios from "axios";
const apiKey = 'sk-proj-FjSRRvxgpVxD3XaKATBXT3BlbkFJXjgnkgNh9UR3RVp5RtpM';
const url = "https://api.openai.com/v1/chat/completions";

// const REST_GAME_API = `http://localhost:8080/ansmoon/problem`;
export const useGameStore = defineStore("game", () => {

    const question = "정답이 '브라질'인 퀴즈에 대한 힌트를 한 줄로 한다면?"
    const hint = ref("");

    const getHint = async() => {           
        await axios.post(
            url, 
            {
                model: 'gpt-3.5-turbo',
                messages: [{ role: 'user', content: question}],
                max_tokens: 100,
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${apiKey}`,
                },
            }
        )
        .then((response) => {
            hint.value = response.data.choices[0].text;
        })
        
    }
    
  return { hint, getHint };
});
