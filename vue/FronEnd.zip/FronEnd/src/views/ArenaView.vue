<template>
    <div>
        <h2>A R E N A</h2>
        <h3>FIGHT!</h3>
        <RouterView/>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>