<template>
    <div>
        <h2>ARENA DETAIL</h2>
        <hr>
        <div>{{ arenaStore.arena.field }}</div>
        <div>{{ arenaStore.arena.starter }}</div>
        <div>{{ arenaStore.arena.openDay }}</div>
        <div>{{ arenaStore.arena.interest }}</div>
        <div>{{ arenaStore.arena.content }}</div>

        <button @click="deleteArena">삭제</button>
        <button @click="updateArena">수정</button>

        <div>
            <h4>FIGHT</h4>
            
        </div>
    </div>
</template>

<script setup>
import { useArenaStore } from '@/stores/arena';
import { onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';

const arenaStore = useArenaStore();
const route = useRoute();
const router = useRouter();

const deleteArena = async() => {
    await arenaStore.deleteArena(route.params.arenaId);
    router.push({ name: "arenaList" });
}

const updateArena = function() {
    router.push({
        name: "updateArena",
        query: {
            arenaId: route.params.arenaId
        },
    })
}

onMounted(() => {
    arenaStore.getArenaNow(route.params.arenaId);
})
</script>

<style scoped>

</style>