package com.project.exercise.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.exercise.dto.OrderCondition;
import com.project.exercise.dto.UserData;
import com.project.exercise.service.ProblemService;

@RestController
@RequestMapping("/ansmoon")
public class ProblemController {
	private ProblemService problemService;
	
	@Autowired
	public ProblemController(ProblemService problemService) {
		this.problemService = problemService;
	}
	
	@GetMapping("/problem/rank")
	public ResponseEntity<List<UserData>> scoreListUp(@ModelAttribute OrderCondition orderCondition){
		System.out.println(orderCondition);
		List<UserData> list = problemService.scoreListUp(orderCondition);
		return new ResponseEntity<List<UserData>>(list, HttpStatus.OK);
	}
}