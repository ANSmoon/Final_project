package com.project.exercise.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.exercise.dao.ProblemDao;
import com.project.exercise.dto.OrderCondition;
import com.project.exercise.dto.UserData;

@Service
public class ProblemServiceImpl implements ProblemService{
	private ProblemDao problemDao;
	
	@Autowired
	public ProblemServiceImpl(ProblemDao problemDao) {
		this.problemDao = problemDao;
	}
	
	@Override
	public List<UserData> scoreListUp(OrderCondition orderCondition) {
		return problemDao.selectScoreAll(orderCondition);
	}
	
}
