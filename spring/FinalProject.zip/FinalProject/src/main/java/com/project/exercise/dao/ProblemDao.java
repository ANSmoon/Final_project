package com.project.exercise.dao;

import java.util.List;

import com.project.exercise.dto.OrderCondition;
import com.project.exercise.dto.UserData;

public interface ProblemDao {
	public List<UserData> selectScoreAll(OrderCondition orderCondition);
}
