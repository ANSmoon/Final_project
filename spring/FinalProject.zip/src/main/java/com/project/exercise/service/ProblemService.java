package com.project.exercise.service;

public interface ProblemService {

}
