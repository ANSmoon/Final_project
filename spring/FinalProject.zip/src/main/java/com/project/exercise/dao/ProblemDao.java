package com.project.exercise.dao;

public interface ProblemDao {

}
