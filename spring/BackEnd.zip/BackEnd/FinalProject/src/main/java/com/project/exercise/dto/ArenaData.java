package com.project.exercise.dto;

public class ArenaData {
	
}
