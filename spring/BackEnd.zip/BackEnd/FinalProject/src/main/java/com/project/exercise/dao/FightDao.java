package com.project.exercise.dao;

import java.util.List;

import com.project.exercise.dto.Fight;

public interface FightDao {
	public List<Fight> selectFightList(int arenaId);
}
