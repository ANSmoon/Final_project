package com.project.exercise.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.exercise.dao.FightDao;
import com.project.exercise.dto.Fight;

@Service
public class FightServiceImpl implements FightService {

	private FightDao fightDao;
	
	public FightServiceImpl(FightDao fightDao) {
		this.fightDao = fightDao;
	}
	
	@Override
	public List<Fight> getFightList(int arenaId) {
		return fightDao.selectFightList(arenaId);
	}

}
