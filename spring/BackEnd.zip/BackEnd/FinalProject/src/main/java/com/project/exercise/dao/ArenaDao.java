package com.project.exercise.dao;

import java.util.List;

import com.project.exercise.dto.Arena;

public interface ArenaDao {
	public List<Arena> selectAllArena();
	
	public Arena selectNowArena(int arenaId);
	
	public Boolean insertArena(Arena arena);
	
	public Boolean deleteArena(int arenaId);
}
