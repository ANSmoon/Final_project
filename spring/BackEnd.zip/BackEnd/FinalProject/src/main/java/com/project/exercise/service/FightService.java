package com.project.exercise.service;

import java.util.List;

import com.project.exercise.dto.Fight;

public interface FightService {
	public List<Fight> getFightList(int arenaId);
}
